package hus.oop.rootsolver;

public class MyMath {
    public static double sin(double x) {
        /* TODO */
    }

    public static double cos(double x) {
        /* TODO */
    }

    public double exp(double x) {
        /* TODO */
    }

    public double ln(double x) {
        /* TODO */
    }
}
