package hus.oop.rootsolver;

public class UnivariateRealFunction implements AbstractFunction {
    @Override
    public double evaluate(double x) {
        /* TODO */
    }

    @Override
    public double derivative(double x) {
        /* TODO */
    }
}
