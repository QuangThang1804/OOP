package com.decorate.Ex1;

public interface Shape {
    void draw();
}
