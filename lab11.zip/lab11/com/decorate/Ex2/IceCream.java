package com.decorate.Ex2;

abstract class IceCream {
    abstract String getDescription();
}
