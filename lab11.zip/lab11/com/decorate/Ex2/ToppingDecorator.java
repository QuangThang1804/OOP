package com.decorate.Ex2;

abstract class ToppingDecorator extends IceCream {
    abstract String addTopping();
}
