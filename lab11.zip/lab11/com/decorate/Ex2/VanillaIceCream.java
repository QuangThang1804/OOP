package com.decorate.Ex2;

public class VanillaIceCream extends IceCream {
    public VanillaIceCream() {

    }

    @Override
    String getDescription() {
        return "Vanilla ice cream";
    }
}
