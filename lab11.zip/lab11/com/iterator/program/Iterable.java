package com.iterator.program;

public interface Iterable {
    Iterator getIterator();
}
