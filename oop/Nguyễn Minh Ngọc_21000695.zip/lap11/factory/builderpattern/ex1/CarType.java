package java_projects.src.hus.oop.lab11.builder_pattern.pseudocode;

public enum CarType {
    CITY_CAR, SPORTS_CAR, SUV
}
