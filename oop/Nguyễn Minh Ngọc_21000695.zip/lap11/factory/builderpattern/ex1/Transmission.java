package java_projects.src.hus.oop.lab11.builder_pattern.pseudocode;

public enum Transmission {
    SINGLE_SPEED, MANUAL, AUTOMATIC, SEMI_AUTOMATIC
}
