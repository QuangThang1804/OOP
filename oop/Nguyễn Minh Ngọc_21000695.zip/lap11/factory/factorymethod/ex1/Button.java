package hus.oop.lap11.factory.factorymethod.ex1;

public interface Button {
    void render();
    void onClick();
}
