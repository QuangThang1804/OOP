package hus.oop.lap11.factory.factorymethod.ex2;

public class CheesePizza extends Pizza{
    public CheesePizza() {
        super.name = "Cheese";
    }
}
