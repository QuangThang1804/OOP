package hus.oop.lap11.factory.factorymethod.ex2;

public class PepperoniPizza extends Pizza{
    public PepperoniPizza() {
        super.name = "Pepperoni";
    }
}
