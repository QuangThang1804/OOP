package hus.oop.lap11.factory.factorymethod.ex3;

public class Apple implements Fruit{
    @Override
    public String produceJuice() {
        return "Apple";
    }
}
