package hus.oop.lap11.factory.factorymethod.ex3;

public class Banana implements Fruit{
    @Override
    public String produceJuice() {
        return "Banana";
    }
}
