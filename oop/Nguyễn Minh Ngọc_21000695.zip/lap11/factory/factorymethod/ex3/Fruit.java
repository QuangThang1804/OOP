package hus.oop.lap11.factory.factorymethod.ex3;

public interface Fruit {
    String produceJuice();
}
