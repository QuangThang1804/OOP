package hus.oop.lap11.factory.factorymethod.ex3;

public class Orange implements Fruit{
    @Override
    public String produceJuice() {
        return "Orange";
    }
}
