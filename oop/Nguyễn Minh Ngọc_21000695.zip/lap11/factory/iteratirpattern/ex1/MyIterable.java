package java_projects.src.hus.oop.lab11.iterator_pattern.diagram;

public interface MyIterable {
    MyIterator getIterator();
}
