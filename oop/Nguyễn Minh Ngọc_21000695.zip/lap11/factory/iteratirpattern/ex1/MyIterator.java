package java_projects.src.hus.oop.lab11.iterator_pattern.diagram;

public interface MyIterator {
    boolean hasNext();
    Object next();
    void remove(int index);
}
