package hus.oop.lap9.lbrary;

import  java.util.StringJoiner;
public abstract class Item {
    private String title;
    private int year;

    public Item(String title, int year){
        this.title = title;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Item{");
        sb.append("title='").append(title);
        sb.append(", year=").append(year);
        sb.append('}');
        return sb.toString();
    }
}
