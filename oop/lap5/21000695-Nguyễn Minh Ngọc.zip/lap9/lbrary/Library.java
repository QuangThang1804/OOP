package hus.oop.lap9.lbrary;
public class Library {
    private Rent[] rents;

    public Library(Rent[] rents) {
        this.rents = rents;
    }

    public Rent getLongestRent() {
        long[] times = new long[rents.length];
        for (int i = 0; i < rents.length; i++) {
            times[i] = rents[i].getEnd().getTime() - rents[i].getBegin().getTime();
        }
        int max_idx = 0;
        for (int i = 1; i < rents.length; i++) {
            if (times[i] > times[max_idx]) {
                max_idx = i;
            }
        }
        return rents[max_idx];
    }
}
