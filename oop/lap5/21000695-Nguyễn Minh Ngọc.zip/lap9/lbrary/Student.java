package hus.oop.lap9.lbrary;

import java.util.Objects;

public class Student implements Comparable<Student> {
    private String firstName;
    private String lastName;
    private String phone;
    private double average;

    public Student(String firstName, String lastName, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
    }

    public Student(String firstName, String lastName, double average) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.average = average;
    }

    public Student(String firstName, String lastName, String phone, double average) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.average = average;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    @Override
    public int compareTo(Student s) {
        return (int) Math.signum(this.average - s.average);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Student student = (Student) o;
        return Double.compare(student.average, average) == 0
                && Objects.equals(student.firstName, firstName)
                && Objects.equals(student.lastName, lastName)
                && Objects.equals(student.phone, phone);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, phone, average);
    }

    @Override
    public String toString() {
        return "Student[" + "firstName = '" + firstName + '\''
                + ", lastName = '" + lastName + '\''
                + ", phone = '" + phone + '\''
                + ", average = " + average + ']';
    }
}

