package hus.oop.lap9.mylist;

public class MyArrayList extends MyAbstractList {
    private int size;
    private final int DEFAULT_CAPACITY = 0;
    private Object[] elements;

    public MyArrayList() {
        elements = new Object[DEFAULT_CAPACITY];
        this.size = 0;
    }

    @Override
    public void remove(int index) {
        checkBoundarles(index, this.size - 1);
        for (int i = index; i <= this.size - 1; i++) {
            this.elements[i] = this.elements[i + 1];
        }
        this.elements[this.size - 1] = null;
        this.size--;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Object get(int index) {
        if (index < 0 || index >= this.size) {
            throw new ArrayIndexOutOfBoundsException();
        }
        checkBoundarles(index, this.size - 1);
        return this.elements[index];
    }

    @Override
    public void add(Object payload, int index) {
        if (this.size == this.elements.length) {
            return;
        }
        checkBoundarles(index, this.size);
        for (int i = this.size; i > index; i--) {
            this.elements[i] = this.elements[i - 1];
        }
        this.elements[index] = payload;
        this.size++;
    }

    @Override
    public void add(Object payload) {
        if (this.size == this.elements.length) {
            this.enlarge();
        }
        this.elements[this.size] = payload;
        this.size++;
    }

    void enlarge() {
        Object[] newData = new Object[2 * this.elements.length];
        for (int i = 0; i < this.elements.length; i++) {
            newData[i] = this.elements[i];
        }
        this.elements = newData;
    }

}