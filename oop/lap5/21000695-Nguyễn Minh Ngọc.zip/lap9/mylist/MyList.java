package hus.oop.lap9.mylist;

public interface MyList {
    void add(Object obj, int size);

    void remove(int id);

    int size();

    Object get(int id);

    void add(Object obj);
}
