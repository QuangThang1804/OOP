package hus.oop.lap9.mylist;

public class TestList {
    public static void main(String[] args) {
        MyList myList = new MyArrayList();
        myList.add("a", 0);
        myList.add("c", 0);
        myList.add("c", 3);

        System.out.println(myList.size());
        System.out.println(myList);

        myList.remove(3);
        System.out.println(myList.size());
        System.out.println(myList);
    }
}
