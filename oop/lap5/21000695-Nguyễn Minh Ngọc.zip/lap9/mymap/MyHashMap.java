package hus.oop.lap9.mymap;

public class MyHashMap implements MyMap {
    private MyHashMapEntry[] table;
    private final int INITIAL_SIZE = 16;
    private int size;

    public MyHashMap() {
        this.table = new MyHashMapEntry[INITIAL_SIZE];
        this.size = 0;
    }

    @Override
    public int size() {
        return size;
    }
    private double capacityRatio() {
        return size*1.0/table.length;
    }

    private int getBucket(Object key) {
        int bucket = Math.abs(key.hashCode()) % table.length;
        while (table[bucket] != null && !table[bucket].getKey().equals(key)) {
            bucket = (bucket+1) % table.length;
        }
        return bucket;
    }

    @Override
    public Object get(Object key) {
        int bucket = getBucket(key);
        if (table[bucket] != null) {
            return table[bucket].getValue();
        }
        return null;
    }

    @Override
    public void put(Object key, Object value) {
        if (capacityRatio() > 0.75) {
            enlarge();
        }
        int bucket = getBucket(key);
        if (table[bucket] == null) {
            table[bucket] = new MyHashMapEntry(key, value);
            size++;
        }
    }

    @Override
    public boolean contains(Object key) {
        Object value = get(key);
        return (value != null);
    }

    @Override
    public void remove(Object key) {
        if (!contains(key)) {
            System.out.println("Map does not contain given key.");
        } else {
            int bucket = getBucket(key);
            table[bucket] = null;
            size--;
        }
    }

    private void enlarge() {
        MyHashMapEntry[] temp = new MyHashMapEntry[2 * table.length];
        System.arraycopy(table, 0, temp, 0, table.length);
        table = temp;
    }
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < table.length; i++) {
            if (table[i] == null) {
                sb.append(String.format("[bucket %d] -> null\n", i));
            } else {
                sb.append(String.format("[bucket %d] -> (%s, %s)\n", i,
                        table[i].getKey(), table[i].getValue()));
            }
        }
        return sb.toString();
    }
}
