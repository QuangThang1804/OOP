package hus.oop.lap9.phonebook;

import java.util.ArrayList;
import java.util.List;

public class PhoneBookList implements PhoneBook {
    private List<Student> phoneBook;

    public PhoneBookList() {
        this.phoneBook = new ArrayList<>();
    }

    @Override
    public void addPerson(Student student) {
        this.phoneBook.add(student);
    }

    @Override
    public Student searchByFirstName(String firstName) {
        for (Student student: phoneBook) {
            if (student.getFirstName().equals(firstName)) {
                return student;
            }
        }
        return null;
    }
    public Student searchByLastName(String lastName) {
        for (Student student: phoneBook) {
            if (student.getLastName().equals(lastName)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public Student searchByNumber(String phone) {
        for (Student student: phoneBook) {
            if (student.getPhone().equals(phone)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public void deleteByNumber(String phone) {
        phoneBook.removeIf(student -> student.getPhone().equals(phone));
    }
}