package hus.oop.lap9.phonebook;

public class Student {
}
