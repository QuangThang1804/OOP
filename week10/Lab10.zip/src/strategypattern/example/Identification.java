package strategypattern.example;

public interface Identification {
    void identify();
}
