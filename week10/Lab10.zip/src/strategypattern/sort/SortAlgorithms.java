package strategypattern.sort;

public interface SortAlgorithms {
    void sort(int[] array);
}
