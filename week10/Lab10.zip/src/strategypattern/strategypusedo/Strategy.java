package strategypattern.strategypusedo;

public interface Strategy {
    int execute(int a, int b);
}
