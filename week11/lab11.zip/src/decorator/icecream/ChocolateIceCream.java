package decorator.icecream;

public class ChocolateIceCream extends IceCream {
    @Override
    String getDescription() {
        return "Chocolate ice cream";
    }
}
