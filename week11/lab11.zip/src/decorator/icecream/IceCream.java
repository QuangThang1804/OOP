package decorator.icecream;

public abstract class IceCream {
    abstract String getDescription();
}
