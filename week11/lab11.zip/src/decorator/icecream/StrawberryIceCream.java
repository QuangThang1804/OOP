package decorator.icecream;

public class StrawberryIceCream extends IceCream {
    @Override
    String getDescription() {
        return "Strawberry ice cream";
    }
}
