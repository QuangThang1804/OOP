package decorator.icecream;

public abstract class ToppingDecorator extends IceCream{
    abstract String addTopping();
}
