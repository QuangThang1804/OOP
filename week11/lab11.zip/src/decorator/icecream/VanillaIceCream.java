package decorator.icecream;

public class VanillaIceCream extends IceCream {
    @Override
    String getDescription() {
        return "Vanilla ice cream";
    }
}
