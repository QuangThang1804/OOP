package decorator.shape;

public interface Shape {
    public void draw();
}
