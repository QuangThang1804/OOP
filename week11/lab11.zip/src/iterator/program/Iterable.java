package iterator.program;

public interface Iterable {
    Iterator getIterator();
}
