package iterator.program;

public interface Iterator {
    boolean hasNext();

    Object next();
}
