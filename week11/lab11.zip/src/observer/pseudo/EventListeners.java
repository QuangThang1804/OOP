package observer.pseudo;

public interface EventListeners {
    void update(String fileName);

//    void update(String fileName);
}
