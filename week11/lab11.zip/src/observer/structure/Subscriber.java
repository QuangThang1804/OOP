package observer.structure;

public interface Subscriber {
    void update(Publisher context);
}
