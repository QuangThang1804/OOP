package observer.subject;

public abstract class Observer {
    public Subject subject;
    public void update(){
    }
}
